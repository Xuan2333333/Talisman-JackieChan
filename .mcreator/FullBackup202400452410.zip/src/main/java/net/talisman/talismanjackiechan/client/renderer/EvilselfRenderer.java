package net.talisman.talismanjackiechan.client.renderer;

import net.talisman.talismanjackiechan.entity.EvilselfEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

public class EvilselfRenderer extends HumanoidMobRenderer<EvilselfEntity, HumanoidModel<EvilselfEntity>> {
	public EvilselfRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<EvilselfEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(EvilselfEntity entity) {
		return ResourceLocation.parse("talisman_jackiechan:textures/entities/evilself.png");
	}
}