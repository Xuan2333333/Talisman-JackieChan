package net.talisman.talismanjackiechan.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class HuProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plr ? _plr.getFoodData().getFoodLevel() : 0) != (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)) {
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(Math.round(((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) + (entity instanceof Player _plr ? _plr.getFoodData().getFoodLevel() : 0)) / 2));
			if (entity instanceof Player _player)
				_player.getFoodData().setFoodLevel(Math.round(((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) + (entity instanceof Player _plr ? _plr.getFoodData().getFoodLevel() : 0)) / 2));
		}
	}
}